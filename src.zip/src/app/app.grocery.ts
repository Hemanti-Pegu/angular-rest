export class Grocery{
    id:number;
    name:string;
    price:number;
    type:string;
}