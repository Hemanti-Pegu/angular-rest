import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { ShowGrocery } from './app.showgrocery';
import { SearchPipe } from './filter';
import { SortingCompaniesPipe } from './app.sortingpipe';
import {UpdateForm} from './app.searchupdate';
@NgModule( {
    imports: [BrowserModule, FormsModule, HttpModule],
    declarations: [AppComponent, ShowGrocery, SearchPipe, SortingCompaniesPipe, UpdateForm],
    bootstrap: [AppComponent]
} )

export class AppModule { }
