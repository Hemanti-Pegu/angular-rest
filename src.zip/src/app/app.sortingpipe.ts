import { Grocery } from './app.grocery';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortingGroceries'
})
export class SortingCompaniesPipe implements PipeTransform {

  transform(groceries: Grocery[], path: string[], order: number): Grocery[] {

    // Check if is not null
    if (!groceries || !path || !order) return groceries;

    return groceries.sort((a: Grocery, b: Grocery) => {
      // We go for each property followed by path
      path.forEach(property => {
        a = a[property];
        b = b[property];
      })

      // Order * (-1): We change our order
      return a > b ? order : order * (- 1);
    });
  }

}