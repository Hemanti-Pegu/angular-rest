import { Injectable } from '@angular/core';
import { Grocery } from './app.grocery';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
import 'rxjs/add/observable/throw';

@Injectable()
export class GroceryService {

    constructor( private http: Http ) { }

    getAllGrocery(): Observable<Grocery[]> {
        return this.http.get( "http://localhost:8085/Grocery/rest/getGrocery" ).
            map(( response: Response ) => <Grocery[]>response.json() );
    }

    deleteGrocery( id: number ): Observable<Grocery[]> {
        return this.http.delete( "http://localhost:8085/Grocery/rest/groDelete/" + id ).
            map(( response: Response ) => <Grocery[]>response.json() )
            .catch( this.handleError );
    }
    handleError( error: Response ) {
        console.error( error );
        return Observable.throw( error );
    }


    updateGrocery( data: Grocery ): Observable<Grocery[]> {
        let groData = JSON.stringify( data );
        //alert( groData );
        let cpHeaders = new Headers( { 'Content-Type': 'application/json' } );
        let options = new RequestOptions( { headers: cpHeaders } );

        return this.http
            .put( 'http://localhost:8085/Grocery/rest/groUpdate/', groData, options )
            .map(( response: Response ) => <Grocery[]>response.json() )
            .catch( this.handleErrorupdate );
    }
    handleErrorupdate( error: Response ) {
        console.error( error );
        return Observable.throw( error );
    }


}