import { Component, OnInit } from '@angular/core';
import { IBook } from './book';
import { BookService } from './book.service';

@Component({
    selector: '<my-component></my-component>',
    templateUrl: './app.bookcomponent.html',
    providers: [BookService]
})

export class BookList implements OnInit {
    books: IBook[];

    search: string = '';
    index: number = 0;

    changeIndexToOne(): void {
        this.index = 1;
        console.log("index changed to: " + this.index);
    }
    changeIndexToTwo(): void {
        this.index = 2;
        console.log("index changed to: " + this.index);
    }
    changeIndexToThree(): void {
        this.index = 3;
        console.log("index changed to: " + this.index);
    }
    changeIndexToFour(): void {
        this.index = 4;
        console.log("index changed to: " + this.index);
    }
    /*id: string = "Id";
    title: string = "Title";
    author: string = "Author";
    year: string = "Year of Publish";*/
    constructor(private bookService: BookService) {
        
    }
    
    ngOnInit(): void {
        console.log("ng-init called...");
        this.bookService.getAllBooks().subscribe((bookData) => this.books = bookData);
    }
}