import { Injectable } from '@angular/core';
import { IBook } from './book';
import {Http,Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"

@Injectable()
export class BookService {
    books: IBook[];
    constructor(private http: Http) {
        
    }
    getAllBooks():Observable< IBook[]> {
            return this.http.get("app/booklist.json").
            map((response: Response) => <IBook[]>response.json());
    }
}

/*[
 {id:1, title: "Android For Expert", author: "George R. R.", yearOfPublish: 1996},
 {id:2, title: "Complete Reference", author: "George P. R. Martin", yearOfPublish: 1998},
 {id:3, title: "BackBone JS", author: "Kalvin R. V.", yearOfPublish: 2000}
];*/