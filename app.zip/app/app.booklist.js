"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var book_service_1 = require("./book.service");
var BookList = (function () {
    /*id: string = "Id";
    title: string = "Title";
    author: string = "Author";
    year: string = "Year of Publish";*/
    function BookList(bookService) {
        this.bookService = bookService;
        this.search = '';
        this.index = 0;
    }
    BookList.prototype.changeIndexToOne = function () {
        this.index = 1;
        console.log("index changed to: " + this.index);
    };
    BookList.prototype.changeIndexToTwo = function () {
        this.index = 2;
        console.log("index changed to: " + this.index);
    };
    BookList.prototype.changeIndexToThree = function () {
        this.index = 3;
        console.log("index changed to: " + this.index);
    };
    BookList.prototype.changeIndexToFour = function () {
        this.index = 4;
        console.log("index changed to: " + this.index);
    };
    BookList.prototype.ngOnInit = function () {
        var _this = this;
        console.log("ng-init called...");
        this.bookService.getAllBooks().subscribe(function (bookData) { return _this.books = bookData; });
    };
    return BookList;
}());
BookList = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.bookcomponent.html',
        providers: [book_service_1.BookService]
    }),
    __metadata("design:paramtypes", [book_service_1.BookService])
], BookList);
exports.BookList = BookList;
